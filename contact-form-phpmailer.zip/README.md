# Contact Form with PHPMailer

This project demonstrates a simple PHP contact form that sends form data to your Gmail inbox using PHPMailer and SMTP.

## Setup Instructions

### 1. Requirements
- PHP & Apache (XAMPP recommended)
- Gmail account with App Password enabled
- PHPMailer library (included in `src/`)

### 2. Configure PHPMailer

In `send_mail.php`, replace:
```
$mail->Username = 'your_email@gmail.com';
$mail->Password = 'your_app_password';
$mail->setFrom('your_email@gmail.com');
$mail->addAddress('your_email@gmail.com');
```

With your actual Gmail address and App Password.

> 📌 App Passwords require 2FA enabled on your Gmail account. [More info here](https://support.google.com/accounts/answer/185833).

### 3. Run Locally

1. Move the folder to `C:/xampp/htdocs/`
2. Start Apache in XAMPP
3. Visit `http://localhost/contact-form/contact.html`
4. Fill out the form and submit — you should receive an email 🎉

---

## Folder Structure

```
contact-form/
├── contact.html
├── send_mail.php
├── src/
│   ├── PHPMailer.php
│   ├── SMTP.php
│   └── Exception.php
```

You can update the layout and style as needed.

---

## License
MIT
